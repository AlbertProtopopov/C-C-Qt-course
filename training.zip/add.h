#ifndef ADD_H
#define ADD_H
//#pragma once

namespace add
{
    class Summ
    {
        public:
            Summ();
            Summ(int i);
            void add(int x, int y);
    };
}

#endif